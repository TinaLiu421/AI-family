import React, { useState, useRef, useEffect } from 'react';
import { SendIcon } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';

export function InputBox() {
  const [text, setText] = useState('');
  const { sendMessage, isTyping, waitingForReply } = useChat();
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  // Auto-focus the input when the component mounts
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);
  
  // Auto-resize the textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
    }
  }, [text]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isTyping && !waitingForReply) {
      sendMessage(text);
      setText('');
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="bg-white border-t p-3 sticky bottom-0 left-0 right-0"
    >
      <div className="relative max-w-3xl mx-auto">
        {isTyping && (
          <div className="absolute -top-8 left-0 bg-gray-700 text-white text-xs px-3 py-1 rounded-full">
            {waitingForReply ? 'Waiting for response...' : 'Ancestor is typing...'}
          </div>
        )}
        <div className="flex items-end border rounded-lg focus-within:ring-2 focus-within:ring-purple-300 bg-white overflow-hidden pr-2">
          <textarea
            ref={inputRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow px-4 py-3 focus:outline-none resize-none max-h-[120px] min-h-[46px]"
            rows={1}
            disabled={isTyping || waitingForReply}
          />
          <button 
            type="submit" 
            className={`p-2 rounded-full ${
              text.trim() && !isTyping && !waitingForReply
                ? 'bg-purple-600 text-white hover:bg-purple-700'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            } transition-colors duration-200`}
            disabled={!text.trim() || isTyping || waitingForReply}
          >
            <SendIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
    </form>
  );
}