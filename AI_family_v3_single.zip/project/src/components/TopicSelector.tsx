import React, { useState } from 'react';
import { 
  CloudIcon, 
  BriefcaseIcon, 
  HeartIcon, 
  LandmarkIcon,
  ComputerIcon, 
  UsersIcon,
  X
} from 'lucide-react';
import { Topic } from '../types';
import { useChat } from '../contexts/ChatContext';

const topicIcons = {
  'Climate Change': CloudIcon,
  'Workplace Culture': BriefcaseIcon,
  'Romantic Relationships': HeartIcon,
  'Political Situation': LandmarkIcon,
  'Technology': ComputerIcon,
  'Family Relationships': UsersIcon
};

export function TopicSelector() {
  const [isOpen, setIsOpen] = useState(false);
  const { topic, setTopic } = useChat();
  
  return (
    <div className="fixed bottom-24 left-4 z-10">
      {isOpen ? (
        <div className="bg-white rounded-lg shadow-lg p-3 w-64 animate-fadeIn">
          <div className="flex justify-between items-center mb-2 pb-2 border-b">
            <h3 className="font-medium text-gray-800">Select a Topic</h3>
            <button 
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-gray-100 rounded-full"
            >
              <X className="h-4 w-4 text-gray-500" />
            </button>
          </div>
          <div className="space-y-2">
            {Object.entries(topicIcons).map(([topicName, Icon]) => {
              const isActive = topic === topicName;
              return (
                <button
                  key={topicName}
                  onClick={() => {
                    setTopic(topicName as Topic);
                    setIsOpen(false);
                  }}
                  className={`flex items-center w-full px-3 py-2 rounded-md transition-colors ${
                    isActive
                      ? 'bg-teal-100 text-teal-700'
                      : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <Icon className={`h-4 w-4 mr-2 ${isActive ? 'text-teal-600' : 'text-gray-500'}`} />
                  <span>{topicName}</span>
                </button>
              );
            })}
            <div className="border-t pt-2 mt-2">
              <button
                onClick={() => {
                  setTopic(null);
                  setIsOpen(false);
                }}
                className="flex items-center w-full px-3 py-2 rounded-md hover:bg-gray-100 text-gray-700"
              >
                <X className="h-4 w-4 mr-2 text-gray-500" />
                <span>Clear Topic</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-teal-600 hover:bg-teal-700 text-white p-3 rounded-full shadow-lg transition-colors flex items-center justify-center"
          aria-label="Select Topic"
        >
          <BriefcaseIcon className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}