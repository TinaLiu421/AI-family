import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Ancestor, Message, Scene, Topic } from '../types';
import { segmentMessage, generateMessageId } from '../utils/messageUtils';

// Sample ancestor data
const defaultAncestor: Ancestor = {
  id: '1',
  name: 'Grandma Elizabeth',
  avatar: 'https://images.pexels.com/photos/2050994/pexels-photo-2050994.jpeg',
  relationship: 'Grandmother',
  description: 'Your loving grandmother who passed away 5 years ago. She was known for her wisdom and warm cookies.'
};

interface ChatContextType {
  messages: Message[];
  isTyping: boolean;
  sendMessage: (text: string) => void;
  ancestor: Ancestor;
  scene: Scene;
  setScene: (scene: Scene) => void;
  topic: Topic | null;
  setTopic: (topic: Topic | null) => void;
  waitingForReply: boolean;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [ancestor] = useState<Ancestor>(defaultAncestor);
  const [scene, setScene] = useState<Scene>('Casual Conversation');
  const [topic, setTopic] = useState<Topic | null>(null);
  const [waitingForReply, setWaitingForReply] = useState(false);

  // Sample ancestor responses based on topics
  const getAncestorResponse = useCallback((userMessage: string, currentTopic: Topic | null, currentScene: Scene) => {
    // Very simple response generation logic - in a real app this would be more sophisticated
    const lowercaseMessage = userMessage.toLowerCase();
    
    if (lowercaseMessage.includes('miss you')) {
      return "I miss you too, dear. It's wonderful to speak with you like this.";
    }
    
    if (lowercaseMessage.includes('how are you')) {
      return "I'm at peace. Don't worry about me. How have you been? I want to hear about your life.";
    }
    
    if (currentTopic === 'Family Relationships') {
      return "Family was always the most important thing to me. Remember that no matter what happens, your family is your foundation. How is everyone doing these days?";
    }
    
    if (currentTopic === 'Climate Change') {
      return "In my day, we didn't talk much about climate change. But we did care for the land and tried not to waste. What's happening with the environment now? It sounds concerning.";
    }
    
    if (currentScene === 'Family Dinner') {
      return "This reminds me of our Sunday dinners. I always loved when everyone gathered around the table. Those were such precious moments. Have you been continuing any of our family traditions?";
    }
    
    // Default response
    return "It's so good to talk to you. What else would you like to tell me about?";
  }, []);

  const addAncestorResponse = useCallback((userMessage: string) => {
    setIsTyping(true);
    
    // Get response based on context
    const responseText = getAncestorResponse(userMessage, topic, scene);
    
    // Segment the message
    const segments = segmentMessage(responseText);
    
    // Schedule the segments to be sent with delays
    segments.forEach((segment, index) => {
      setTimeout(() => {
        // Last segment
        if (index === segments.length - 1) {
          setMessages(prev => [
            ...prev,
            {
              id: generateMessageId(),
              text: segment,
              sender: 'ancestor',
              timestamp: new Date()
            }
          ]);
          setIsTyping(false);
          setWaitingForReply(false);
        } else {
          // Earlier segments
          setMessages(prev => [
            ...prev,
            {
              id: generateMessageId(),
              text: segment,
              sender: 'ancestor',
              timestamp: new Date()
            }
          ]);
        }
      }, 1000 + (index * 1500)); // First response after 1s, then 1.5s between segments
    });
  }, [getAncestorResponse, topic, scene]);

  const sendMessage = useCallback((text: string) => {
    if (!text.trim()) return;
    
    // Add user message
    const userMessage = {
      id: generateMessageId(),
      text,
      sender: 'user' as const,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setWaitingForReply(true);
    
    // Schedule the ancestor's response with a 3-second delay
    setTimeout(() => {
      addAncestorResponse(text);
    }, 3000);
  }, [addAncestorResponse]);
  
  // Initial greeting
  useEffect(() => {
    setTimeout(() => {
      addAncestorResponse("Hello");
    }, 1000);
  }, [addAncestorResponse]);

  return (
    <ChatContext.Provider 
      value={{ 
        messages, 
        isTyping, 
        sendMessage, 
        ancestor, 
        scene, 
        setScene, 
        topic, 
        setTopic,
        waitingForReply
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}