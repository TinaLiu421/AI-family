export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ancestor';
  timestamp: Date;
}

export interface Ancestor {
  id: string;
  name: string;
  avatar: string;
  relationship: string;
  description: string;
}

export type Scene = 'Family Dinner' | 'Weekend Chat' | 'Holiday Event' | 'Birthday' | 'Casual Conversation';

export type Topic = 
  | 'Climate Change' 
  | 'Workplace Culture' 
  | 'Romantic Relationships' 
  | 'Political Situation' 
  | 'Technology' 
  | 'Family Relationships';