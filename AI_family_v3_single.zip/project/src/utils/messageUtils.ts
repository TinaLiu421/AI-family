/**
 * Split a message text into segments based on punctuation
 */
export function segmentMessage(text: string): string[] {
  // Split by punctuation (.?!) followed by a space or end of string
  const segments = text.match(/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g) || [];
  
  // Trim each segment and filter out empty ones
  return segments
    .map(segment => segment.trim())
    .filter(segment => segment.length > 0);
}

/**
 * Generate a unique ID for messages
 */
export function generateMessageId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}